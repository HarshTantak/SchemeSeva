import React from 'react';
import './Navbar.css';

const Navbar = () => (
  <nav className="navbar">
    <div className="navbar-logo">
      <img src="/lion_logo.png" alt="Government of India Logo" className="logo-img" />
      <span className="navbar-title">SchemeSeva</span>
    </div>
    <ul className="navbar-links">
      <li><a href="/">Home</a></li>
      <li><a href="/about">About</a></li>
      <li><a href="/schemes">Schemes</a></li>
      <li><a href="/user-schemes">User Schemes</a></li>
      <li><a href="/suggests">Suggests</a></li>
      <li><span className="profile-icon">&#128100;</span></li>
    </ul>
  </nav>
);

export default Navbar; 