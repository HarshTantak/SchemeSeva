import React, { useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import './VoiceAssistant.css';

async function translateText(text, targetLang = 'en') {
  const res = await fetch('https://libretranslate.com/translate', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      q: text,
      source: 'auto',
      target: targetLang,
      format: 'text'
    })
  });
  const data = await res.json();
  return data.translatedText;
}

const VoiceAssistant = () => {
  const [open, setOpen] = useState(false);
  const [recording, setRecording] = useState(false);
  const [transcription, setTranscription] = useState('');
  const [loading, setLoading] = useState(false);
  const [query, setQuery] = useState('');
  const [translatedQuery, setTranslatedQuery] = useState('');
  const [recommendations, setRecommendations] = useState([]);
  const recognitionRef = useRef(null);

  const startRecognition = () => {
    setTranscription('');
    setRecording(true);
    setLoading(false);
    if (!('webkitSpeechRecognition' in window || 'SpeechRecognition' in window)) {
      setTranscription('Sorry, your browser does not support speech recognition.');
      setRecording(false);
      return;
    }
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    recognition.lang = 'en-IN'; // or 'hi-IN' for Hindi
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;
    recognition.onresult = (event) => {
      setTranscription(event.results[0][0].transcript);
      setQuery(event.results[0][0].transcript);
      setLoading(false);
    };
    recognition.onerror = (event) => {
      setTranscription('Error: ' + event.error);
      setLoading(false);
    };
    recognition.onend = () => {
      setRecording(false);
      setLoading(false);
    };
    recognitionRef.current = recognition;
    setLoading(true);
    recognition.start();
  };

  const stopRecognition = () => {
    setRecording(false);
    setLoading(false);
    if (recognitionRef.current) {
      recognitionRef.current.stop();
    }
  };

  const handleQueryChange = (e) => {
    setQuery(e.target.value);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!query.trim()) return;
    setLoading(true);
    setTranslatedQuery('');
    setRecommendations([]);
    try {
      const translated = await translateText(query, 'en');
      setTranslatedQuery(translated);
      const res = await fetch('http://localhost:5002/voice-recommend', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: translated })
      });
      const data = await res.json();
      setRecommendations(data.recommendations);
    } catch (err) {
      setTranslatedQuery('');
      setRecommendations([]);
    }
    setLoading(false);
  };

  return (
    <>
      <button className="voice-assistant-btn" onClick={() => setOpen(true)}>
        <span role="img" aria-label="mic">🎤</span>
      </button>
      {open && (
        <div className="voice-modal-overlay" onClick={() => setOpen(false)}>
          <div className="voice-modal" onClick={e => e.stopPropagation()}>
            <div className="voice-modal-header">
              <span>Voice Assistant</span>
              <button className="voice-modal-close" onClick={() => setOpen(false)}>×</button>
            </div>
            <form className="voice-modal-body" onSubmit={handleSubmit}>
              <input
                type="text"
                className="voice-query-input"
                placeholder="Type your query or use voice..."
                value={query}
                onChange={handleQueryChange}
                disabled={loading}
                autoFocus
              />
              <div className="voice-or">or</div>
              <button
                type="button"
                className={`voice-record-btn${recording ? ' recording' : ''}`}
                onMouseDown={startRecognition}
                onMouseUp={stopRecognition}
                onTouchStart={startRecognition}
                onTouchEnd={stopRecognition}
                disabled={loading}
              >
                {recording ? 'Listening...' : 'Hold to Speak'}
              </button>
              <button type="submit" className="voice-submit-btn" disabled={loading || !query.trim()}>
                Search
              </button>
            </form>
            <div className="voice-modal-results">
              {loading && <div className="voice-loader">Processing...</div>}
              {translatedQuery && (
                <div className="voice-translated-query">Translated Query: <b>{translatedQuery}</b></div>
              )}
              {recommendations.length > 0 && (
                <div className="voice-recommendations-list">
                  {recommendations.map((rec, idx) => (
                    <Link to={`/schemes/${rec._id || idx}`} className="voice-recommendation-card" key={idx}>
                      <div className="voice-recommendation-title">{rec['Scheme Name']}</div>
                      <div className="voice-recommendation-details-snippet">{(rec['Details'] || '').slice(0, 90)}{rec['Details'] && rec['Details'].length > 90 ? '...' : ''}</div>
                      <div className="voice-recommendation-link">View Details</div>
                    </Link>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default VoiceAssistant; 