import React, { useEffect, useState } from 'react';
import './Home.css';
import { useNavigate } from 'react-router-dom';

const CATEGORY_KEYWORDS = {
  Education: [
    'school', 'education', 'scholar', 'student', 'tuition', 'university', 'college', 'admission', 'hostel', 'exam', 'merit', 'fellowship', 'learning', 'study', 'class', 'teacher', 'academic', 'fee', 'scholarship', 'literacy', 'training', 'grant'
  ],
  Healthcare: [
    'health', 'hospital', 'medical', 'doctor', 'medicine', 'treatment', 'insurance', 'illness', 'disease', 'clinic', 'surgery', 'diagnosis', 'care', 'wellness', 'immunization', 'vaccination', 'covid', 'cancer', 'therapy', 'disability', 'patient', 'nurse', 'sanitation'
  ],
  'Women Empowerment': [
    'women', 'girl', 'female', 'widow', 'pregnant', 'maternity', 'mother', 'daughter', 'ladies', 'mahila', 'beti', 'matritva', 'empowerment', 'gender'
  ],
  Employment: [
    'employment', 'job', 'work', 'unemployment', 'skill', 'apprentice', 'recruitment', 'placement', 'labour', 'employee', 'employer', 'career', 'vacancy', 'wage', 'salary', 'intern', 'self-employment', 'entrepreneur', 'startup', 'business', 'industry', 'livelihood'
  ],
  Housing: [
    'housing', 'house', 'home', 'shelter', 'residence', 'flat', 'apartment', 'dwelling', 'accommodation', 'pradhan mantri awas', 'rental', 'construction', 'urban', 'rural', 'slum', 'property', 'land', 'plot', 'real estate', 'residential'
  ],
  Agriculture: [
    'agriculture', 'farmer', 'crop', 'farming', 'irrigation', 'seed', 'fertilizer', 'pesticide', 'tractor', 'harvest', 'dairy', 'horticulture', 'animal husbandry', 'kisan', 'agro', 'rural', 'soil', 'organic', 'fisheries', 'poultry', 'plantation', 'agrarian', 'market', 'mandi'
  ],
  'Skill Development': [
    'skill', 'training', 'development', 'capacity', 'upskill', 'reskill', 'vocational', 'workshop', 'certification', 'course', 'apprentice', 'learning', 'entrepreneur', 'startup', 'talent', 'coaching', 'mentoring', 'digital literacy', 'computer', 'technology'
  ],
  Transportation: [
    'transport', 'bus', 'train', 'railway', 'road', 'highway', 'vehicle', 'travel', 'commute', 'metro', 'flight', 'airport', 'shipping', 'logistics', 'ferry', 'public transport', 'infrastructure', 'mobility', 'traffic', 'driver', 'license', 'automobile'
  ],
};

const categories = Object.keys(CATEGORY_KEYWORDS);

function categorizeScheme(scheme) {
  const text = (
    (scheme['Scheme Name'] || '') + ' ' +
    (scheme['Details'] || '') + ' ' +
    (scheme['Keywords'] || '')
  ).toLowerCase();
  for (const category of categories) {
    for (const keyword of CATEGORY_KEYWORDS[category]) {
      if (text.includes(keyword)) {
        return category;
      }
    }
  }
  return 'Other';
}

const Home = () => {
  const [schemes, setSchemes] = useState([]);
  const [categoryCounts, setCategoryCounts] = useState({});
  const navigate = useNavigate();

  useEffect(() => {
    fetch('http://localhost:8000/api/schemes')
      .then(res => res.json())
      .then(data => {
        setSchemes(data);
        // Categorize schemes
        const counts = {};
        categories.forEach(cat => (counts[cat] = 0));
        data.forEach(scheme => {
          const cat = categorizeScheme(scheme);
          if (counts[cat] !== undefined) counts[cat]++;
        });
        setCategoryCounts(counts);
      });
  }, []);

  const handleCategoryClick = (cat) => {
    navigate(`/category/${encodeURIComponent(cat)}`);
  };

  return (
    <div className="home-container">
      {/* Hero Section */}
      <section className="hero-section">
        <div className="hero-content">
          <h1>Explore Government Schemes for You</h1>
          <p>Get information about all the government schemes, categorized and easy to explore</p>
          <a href="/schemes" className="explore-btn">Explore Schemes</a>
        </div>
      </section>

      {/* Stats Section */}
      <section className="stats-section">
        <div className="stat-card"><span className="stat-number">3400+</span><span>Total Schemes Available</span></div>
        <a href="/user-schemes" className="user-schemes-btn">User Based Schemes</a>
      </section>

      {/* Categories Section */}
      <section className="categories-section">
        <h2>Browse by Category</h2>
        <div className="categories-grid">
          {categories.map(cat => (
            <div className="category-card" key={cat} onClick={() => handleCategoryClick(cat)} style={{cursor:'pointer'}}>
              <div className="category-icon">📁</div>
              <div className="category-name">{cat}</div>
              <div className="category-count">{categoryCounts[cat] || 0}+ schemes available</div>
            </div>
          ))}
        </div>
      </section>

      {/* How to Apply Section */}
      <section className="howto-section">
        <h2>How to Apply</h2>
        <div className="howto-steps">
          <div className="howto-step"><div className="howto-icon">➕</div><div>Enter Details</div><p>Start by entering your details to find relevant schemes</p></div>
          <div className="howto-step"><div className="howto-icon">🔍</div><div>Search</div><p>Our search engine helps you find the relevant schemes</p></div>
          <div className="howto-step"><div className="howto-icon">✅</div><div>Select and Apply</div><p>Choose the schemes you're eligible for and apply online</p></div>
        </div>
      </section>

      {/* About Us Section */}
      <section className="about-section">
        <h2>About Us</h2>
        <p>We are dedicated to bridging the gap between citizens and government schemes. Our mission is to provide easy access to all government schemes, ensuring that every citizen can take advantage of the benefits they are entitled to.</p>
        <div className="about-cards">
          <div><div className="about-icon">🎯</div><div>Our Mission</div><p>To empower citizens by providing comprehensive information about government schemes.</p></div>
          <div><div className="about-icon">👥</div><div>Who We Serve</div><p>All citizens looking to benefit from government initiatives and programs.</p></div>
          <div><div className="about-icon">🛡️</div><div>Our Commitment</div><p>Providing accurate, up-to-date information and guidance on all available schemes.</p></div>
        </div>
        <a href="/about" className="about-btn">Learn More About Us</a>
      </section>
    </div>
  );
};

export default Home; 