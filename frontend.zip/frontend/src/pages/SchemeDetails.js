import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import './SchemeDetails.css';

const fieldLabels = {
  'Scheme Name': 'Scheme Name',
  'Scheme Category': 'Category',
  'Keywords': 'Keywords',
  'Details': 'Details',
  'Benefits': 'Benefits',
  'Eligibility': 'Eligibility',
  'Exclusions': 'Exclusions',
  'Documents Required': 'Documents Required',
  'URL': 'Official Link',
};

const SchemeDetails = () => {
  const { id } = useParams();
  const [scheme, setScheme] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch(`http://localhost:8000/api/schemes/${id}`)
      .then(res => res.json())
      .then(data => {
        setScheme(data);
        setLoading(false);
      });
  }, [id]);

  if (loading) return <div style={{ padding: 32 }}>Loading...</div>;
  if (!scheme) return <div style={{ padding: 32 }}>Scheme not found.</div>;

  return (
    <div className="scheme-details-container">
      <Link to="/schemes" className="back-link">← Back to Schemes</Link>
      <h1>{scheme['Scheme Name']}</h1>
      <div className="scheme-details-list">
        {Object.keys(fieldLabels).map(key => (
          scheme[key] ? (
            <div className="scheme-detail-row" key={key}>
              <span className="scheme-detail-label">{fieldLabels[key]}:</span>
              {key === 'URL' ? (
                <a href={scheme[key]} target="_blank" rel="noopener noreferrer">{scheme[key]}</a>
              ) : (
                <span className="scheme-detail-value">{scheme[key]}</span>
              )}
            </div>
          ) : null
        ))}
      </div>
    </div>
  );
};

export default SchemeDetails; 