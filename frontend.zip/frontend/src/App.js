import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import About from './pages/About';
import Schemes from './pages/Schemes';
import SchemeDetails from './pages/SchemeDetails';
import Suggests from './pages/Suggests';
import UserSchemes from './pages/UserSchemes';
import CategoryPage from './pages/CategoryPage';
import VoiceAssistant from './components/VoiceAssistant';
import './App.css';

function App() {
  return (
    <Router>
      <Navbar />
      <div className="main-content">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/schemes" element={<Schemes />} />
          <Route path="/schemes/:id" element={<SchemeDetails />} />
          <Route path="/user-schemes" element={<UserSchemes />} />
          <Route path="/category/:categoryName" element={<CategoryPage />} />
          <Route path="/suggests" element={<Suggests />} />
        </Routes>
      </div>
      <VoiceAssistant />
    </Router>
  );
}

export default App;
