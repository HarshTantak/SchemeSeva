import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import './CategoryPage.css';

const CATEGORY_KEYWORDS = {
  Education: [
    'school', 'education', 'scholar', 'student', 'tuition', 'university', 'college', 'admission', 'hostel', 'exam', 'merit', 'fellowship', 'learning', 'study', 'class', 'teacher', 'academic', 'fee', 'scholarship', 'literacy', 'training', 'grant'
  ],
  Healthcare: [
    'health', 'hospital', 'medical', 'doctor', 'medicine', 'treatment', 'insurance', 'illness', 'disease', 'clinic', 'surgery', 'diagnosis', 'care', 'wellness', 'immunization', 'vaccination', 'covid', 'cancer', 'therapy', 'disability', 'patient', 'nurse', 'sanitation'
  ],
  'Women Empowerment': [
    'women', 'girl', 'female', 'widow', 'pregnant', 'maternity', 'mother', 'daughter', 'ladies', 'mahila', 'beti', 'matritva', 'empowerment', 'gender'
  ],
  Employment: [
    'employment', 'job', 'work', 'unemployment', 'skill', 'apprentice', 'recruitment', 'placement', 'labour', 'employee', 'employer', 'career', 'vacancy', 'wage', 'salary', 'intern', 'self-employment', 'entrepreneur', 'startup', 'business', 'industry', 'livelihood'
  ],
  Housing: [
    'housing', 'house', 'home', 'shelter', 'residence', 'flat', 'apartment', 'dwelling', 'accommodation', 'pradhan mantri awas', 'rental', 'construction', 'urban', 'rural', 'slum', 'property', 'land', 'plot', 'real estate', 'residential'
  ],
  Agriculture: [
    'agriculture', 'farmer', 'crop', 'farming', 'irrigation', 'seed', 'fertilizer', 'pesticide', 'tractor', 'harvest', 'dairy', 'horticulture', 'animal husbandry', 'kisan', 'agro', 'rural', 'soil', 'organic', 'fisheries', 'poultry', 'plantation', 'agrarian', 'market', 'mandi'
  ],
  'Skill Development': [
    'skill', 'training', 'development', 'capacity', 'upskill', 'reskill', 'vocational', 'workshop', 'certification', 'course', 'apprentice', 'learning', 'entrepreneur', 'startup', 'talent', 'coaching', 'mentoring', 'digital literacy', 'computer', 'technology'
  ],
  Transportation: [
    'transport', 'bus', 'train', 'railway', 'road', 'highway', 'vehicle', 'travel', 'commute', 'metro', 'flight', 'airport', 'shipping', 'logistics', 'ferry', 'public transport', 'infrastructure', 'mobility', 'traffic', 'driver', 'license', 'automobile'
  ],
};

const categories = Object.keys(CATEGORY_KEYWORDS);

function categorizeScheme(scheme) {
  const text = (
    (scheme['Scheme Name'] || '') + ' ' +
    (scheme['Details'] || '') + ' ' +
    (scheme['Keywords'] || '')
  ).toLowerCase();
  for (const category of categories) {
    for (const keyword of CATEGORY_KEYWORDS[category]) {
      if (text.includes(keyword)) {
        return category;
      }
    }
  }
  return 'Other';
}

const fieldLabels = {
  'Scheme Name': 'Scheme Name',
  'Scheme Category': 'Category',
  'Keywords': 'Keywords',
  'Details': 'Details',
  'Benefits': 'Benefits',
  'Eligibility': 'Eligibility',
  'Exclusions': 'Exclusions',
  'Documents Required': 'Documents Required',
  'URL': 'Official Link',
};

const CategoryPage = () => {
  const { categoryName } = useParams();
  const [schemes, setSchemes] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('http://localhost:8000/api/schemes')
      .then(res => res.json())
      .then(data => {
        const filtered = data.filter(s => categorizeScheme(s) === categoryName);
        setSchemes(filtered);
        setLoading(false);
      });
  }, [categoryName]);

  return (
    <div className="category-page-container">
      <h1>{categoryName} Schemes</h1>
      {loading ? (
        <div>Loading...</div>
      ) : schemes.length === 0 ? (
        <div>No schemes found in this category.</div>
      ) : (
        <div className="category-schemes-list">
          {schemes.map(scheme => (
            <Link to={`/schemes/${scheme._id}`} className="category-scheme-card" key={scheme._id}>
              <div className="category-scheme-title">{scheme['Scheme Name']}</div>
              <div className="category-scheme-details-snippet">{(scheme['Details'] || '').slice(0, 90)}{scheme['Details'] && scheme['Details'].length > 90 ? '...' : ''}</div>
              <div className="category-scheme-link">View Details</div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
};

export default CategoryPage; 