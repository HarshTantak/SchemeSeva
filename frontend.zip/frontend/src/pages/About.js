import React from 'react';

const About = () => (
  <div style={{ padding: '32px', maxWidth: 800, margin: '0 auto' }}>
    <h1>About SchemeSeva</h1>
    <p>
      SchemeSeva is dedicated to bridging the gap between citizens and government schemes. Our mission is to provide easy access to all government schemes, ensuring that every citizen can take advantage of the benefits they are entitled to. We provide accurate, up-to-date information and guidance on all available schemes.
    </p>
  </div>
);

export default About; 