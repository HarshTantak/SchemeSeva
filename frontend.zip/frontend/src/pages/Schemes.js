import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import './Schemes.css';

const Schemes = () => {
  const [schemes, setSchemes] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('http://localhost:8000/api/schemes')
      .then(res => res.json())
      .then(data => {
        setSchemes(data);
        setLoading(false);
      });
  }, []);

  return (
    <div className="schemes-container">
      <h1>All Government Schemes</h1>
      {loading ? (
        <div>Loading...</div>
      ) : (
        <div className="schemes-grid">
          {schemes.map(scheme => (
            <Link to={`/schemes/${scheme._id}`} className="scheme-card" key={scheme._id}>
              <div className="scheme-title">{scheme['Scheme Name']}</div>
              <div className="scheme-category">{scheme['Scheme Category']}</div>
              <div className="scheme-details">{(scheme['Details'] || '').slice(0, 90)}...</div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
};

export default Schemes; 