import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import './UserSchemes.css';

const states = [
  'Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chhattisgarh',
  'Goa', 'Gujarat', 'Haryana', 'Himachal Pradesh', 'Jharkhand',
  'Karnataka', 'Kerala', 'Madhya Pradesh', 'Maharashtra', 'Manipur',
  'Meghalaya', 'Mizoram', 'Nagaland', 'Odisha', 'Punjab',
  'Rajasthan', 'Sikkim', 'Tamil Nadu', 'Telangana', 'Tripura',
  'Uttar Pradesh', 'Uttarakhand', 'West Bengal', 'Delhi', 'Jammu and Kashmir',
  'Ladakh', 'Puducherry', 'Chandigarh', 'Andaman and Nicobar Islands',
  'Lakshadweep', 'Dadra and Nagar Haveli and Daman and Diu'
];

const UserSchemes = () => {
  const [form, setForm] = useState({
    name: '',
    age: '',
    gender: '',
    state: '',
    occupation: '',
    income: '',
  });
  const [submitted, setSubmitted] = useState(false);
  const [recommendations, setRecommendations] = useState([]);

  const handleChange = e => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = e => {
    e.preventDefault();
    setSubmitted(true);
  };

  useEffect(() => {
    if (submitted) {
      fetch('http://localhost:5002/recommend', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form)
      })
        .then(res => res.json())
        .then(data => setRecommendations(data));
    }
  }, [submitted, form]);

  if (submitted) {
    return (
      <div className="user-schemes-container">
        <h1>Thank you!</h1>
        <p>Your details have been saved.</p>
        <div className="user-summary">
          <div><b>Name:</b> {form.name}</div>
          <div><b>Age:</b> {form.age}</div>
          <div><b>Gender:</b> {form.gender}</div>
          <div><b>State:</b> {form.state}</div>
          <div><b>Occupation:</b> {form.occupation}</div>
          <div><b>Income:</b> {form.income}</div>
        </div>
        {recommendations.length > 0 && (
          <div className="user-recommendations">
            <h2>Recommended Schemes for You</h2>
            <div className="user-recommendations-list">
              {recommendations.map((rec, idx) => (
                <Link to={`/schemes/${rec._id || idx}`} className="user-recommendation-card" key={idx}>
                  <div className="user-recommendation-title">{rec['Scheme Name']}</div>
                  <div className="user-recommendation-details-snippet">{(rec['Details'] || '').slice(0, 90)}{rec['Details'] && rec['Details'].length > 90 ? '...' : ''}</div>
                  <div className="user-recommendation-link">View Details</div>
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="user-schemes-container">
      <h1>User Based Schemes</h1>
      <form className="user-schemes-form" onSubmit={handleSubmit}>
        <label>Name
          <input type="text" name="name" value={form.name} onChange={handleChange} required />
        </label>
        <label>Age
          <input type="number" name="age" value={form.age} onChange={handleChange} min="1" required />
        </label>
        <label>Gender
          <select name="gender" value={form.gender} onChange={handleChange} required>
            <option value="">Select</option>
            <option value="male">Male</option>
            <option value="female">Female</option>
          </select>
        </label>
        <label>Location (State)
          <select name="state" value={form.state} onChange={handleChange} required>
            <option value="">Select State</option>
            {states.map(s => <option key={s} value={s}>{s}</option>)}
          </select>
        </label>
        <label>Occupation
          <input type="text" name="occupation" value={form.occupation} onChange={handleChange} required />
        </label>
        <label>Income
          <input type="number" name="income" value={form.income} onChange={handleChange} min="0" required />
        </label>
        <button type="submit" className="user-schemes-submit">Save</button>
      </form>
    </div>
  );
};

export default UserSchemes; 