import React from 'react';

const Suggests = () => (
  <div style={{ padding: '32px', maxWidth: 800, margin: '0 auto' }}>
    <h1>Suggest a Scheme</h1>
    <p>
      This feature will allow users to suggest new schemes or improvements. Stay tuned!
    </p>
  </div>
);

export default Suggests; 